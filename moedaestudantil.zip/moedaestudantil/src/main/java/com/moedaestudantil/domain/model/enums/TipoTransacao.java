package com.moedaestudantil.domain.model.enums;
public enum TipoTransacao { ENVIO_PROFESSOR, RESGATE_ALUNO, CREDITO_SEMESTRAL }
