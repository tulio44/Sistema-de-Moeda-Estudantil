package com.moedaestudantil.domain.model.enums;
public enum Role { ALUNO, PROFESSOR, EMPRESA }
